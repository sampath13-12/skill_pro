package com.project.learnHub.service;

import com.project.learnHub.entity.Courses;

import java.util.List;

public interface ICourseService {

    Courses addCourses(Courses course);

    List<Courses> findAllCourses();
}
