package com.project.learnHub.repository;

import com.project.learnHub.entity.Blogs;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BlogsRepository extends JpaRepository<Blogs,Long> {
}
