package com.project.learnHub.service;

import com.project.learnHub.entity.Notes;

import java.util.List;

public interface INotesService {

    Notes addNotes(Notes notes);

    List<Notes> findAllNotes();
}
