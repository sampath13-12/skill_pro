package com.project.learnHub.service;

import com.project.learnHub.entity.*;

public interface IStudentService {

    Student register(Student student);

    Object login(String username, String password);

    Courses viewCourses();

    JobNotification viewJobNotification();

    Blogs addBlogs(Blogs blogs);

    Blogs viewBlogs();

    Notes addNotes(Notes notes);

    Notes viewNotes();



}
