package com.project.learnHub.service;

import com.project.learnHub.entity.Blogs;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface IBlogService {

     Blogs addBlogs(Blogs blog);

}
