package com.project.learnHub.service.Impl;

import com.project.learnHub.entity.JobNotification;
import com.project.learnHub.repository.NotificationRepository;
import com.project.learnHub.service.INotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificationService implements INotificationService {


    @Autowired
    private NotificationRepository notificationRepository;

    @Override
    public JobNotification addJobNotifications(JobNotification notification) {
        return notificationRepository.save(notification);
    }

    @Override
    public List<JobNotification> findAllNotifications() {
        return notificationRepository.findAll();
    }
}
