package com.project.learnHub.service.Impl;

import com.project.learnHub.entity.Blogs;
import com.project.learnHub.repository.BlogsRepository;
import com.project.learnHub.service.IBlogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class BlogService implements IBlogService {

//    @Value("${app.upload.path:src/main/resources/static}")
//    private String staticFolderPath;

    @Autowired
    private BlogsRepository blogsRepository;

    @Override
    public Blogs addBlogs(Blogs blog) {
        return blogsRepository.save(blog);
    }



//    private String saveFile(MultipartFile file, String folderName) throws IOException {
//        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
//        Path targetLocation = Paths.get(staticFolderPath, folderName, fileName);
//
//        Files.createDirectories(targetLocation.getParent());
//
//        Files.copy(file.getInputStream(), targetLocation);
//
//        return "/static/" + folderName + "/" + fileName;
//    }


}
