package com.project.learnHub.service.Impl;

import com.project.learnHub.entity.Courses;
import com.project.learnHub.repository.CourseRepository;
import com.project.learnHub.service.ICourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseService implements ICourseService {

    @Autowired
    private CourseRepository courseRepository;

    @Override
    public Courses addCourses(Courses course) {
        return courseRepository.save(course);
    }

    @Override
    public List<Courses> findAllCourses() {
        return courseRepository.findAll();
    }
}
