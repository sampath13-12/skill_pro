package com.project.learnHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ELearnHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
