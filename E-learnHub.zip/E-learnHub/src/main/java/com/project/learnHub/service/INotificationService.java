package com.project.learnHub.service;

import com.project.learnHub.entity.Courses;
import com.project.learnHub.entity.JobNotification;

import java.util.List;

public interface INotificationService {

    JobNotification addJobNotifications(JobNotification notification);

    List<JobNotification>  findAllNotifications();
}
