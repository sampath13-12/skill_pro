package com.project.learnHub.repository;

import com.project.learnHub.entity.JobNotification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificationRepository extends JpaRepository<JobNotification,Long> {
}
