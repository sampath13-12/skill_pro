package com.project.learnHub.repository;

import com.project.learnHub.entity.Placement;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlacementRepository extends JpaRepository<Placement,Long> {
}
