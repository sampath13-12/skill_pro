package com.project.learnHub.service.Impl;

import com.project.learnHub.entity.Notes;
import com.project.learnHub.repository.NotesRepository;
import com.project.learnHub.service.INotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotesService implements INotesService {

    @Autowired
    private NotesRepository notesRepository;

    @Override
    public Notes addNotes(Notes notes) {
        return notesRepository.save(notes) ;
    }

    @Override
    public List<Notes> findAllNotes() {
        return notesRepository.findAll();
    }
}
