package com.project.learnHub.service.Impl;

import com.project.learnHub.entity.Courses;
import com.project.learnHub.entity.JobNotification;
import com.project.learnHub.service.IAdminService;
import org.springframework.stereotype.Service;

@Service
public class AdminService implements IAdminService {
    @Override
    public Courses addCourses(Courses course) {
        return null;
    }

    @Override
    public JobNotification addJobNotification(JobNotification jobNotification) {
        return null;
    }
}
