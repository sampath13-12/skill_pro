package com.project.learnHub.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.project.learnHub.entity.*;
import com.project.learnHub.repository.CareerRepository;
import com.project.learnHub.repository.PlacementRepository;
import com.project.learnHub.service.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/student")
public class StudentController {

    @Autowired
    private CareerRepository careerRepository;

    @Autowired
    private PlacementRepository placementRepository;

    @Autowired
    private IStudentService studentService;

    @Autowired
    private ICourseService courseService;

    @Autowired
    private INotificationService notificationService;

    @Autowired
    private IBlogService blogService;

    @Autowired
    private INotesService notesService;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Student student){
        HashMap<String, Object> response = new HashMap<>();
        try {
            if (student.getName() == null || student.getPassword() == null || student.getEmail() == null || student.getCategory() == null) {
                response.put("msg", "Username and Password fields are required");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }
            Student registeredUser = studentService.register(student);
            response.put("msg", "Registration successful");
            response.put("userId", registeredUser.getId());
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            response.put("msg", e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
        } catch (Exception e) {
            response.put("msg", "An error occurred during registration");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login (@RequestBody HashMap<String, String> loginRequest){
        HashMap<String, Object> response = new HashMap<>();
        try {

            String username = loginRequest.get("username");
            String password = loginRequest.get("password");

            if (username == null || password == null) {
                response.put("msg", "Username and Password fields are required");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

             Optional <Student> studentLogin = (Optional<Student>) studentService.login(username,password);
            if (studentLogin.isPresent()) {
                response.put("msg", "Login successful");
                response.put("userId", studentLogin.get().getId());
                response.put("username",studentLogin.get().getName());
                return ResponseEntity.ok(response);
            } else {
                response.put("msg", "Invalid username or password");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }
        } catch (Exception e) {
            response.put("msg", "An error occurred during login");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/view-courses")
    public ResponseEntity<?> findAllCourses(){
        try{
            List<Courses> courses = courseService.findAllCourses();
            return new ResponseEntity<>(courses,HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/view-notifications")
    public ResponseEntity<?> findAllNotifications(){
        try{
            List<JobNotification> notifications = notificationService.findAllNotifications();
            return new ResponseEntity<>(notifications,HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



//    @PostMapping("/add-blogs")  exxample code last prference
//    public ResponseEntity<?> addBlogs(
//            @RequestParam("title") String title,
//            @RequestBody Career career,
//            @RequestBody Placement placement,
//            @RequestParam("video") MultipartFile video,
//            @RequestParam("document") MultipartFile document) {
//
//        HashMap<String, Object> response = new HashMap<>();
//        try {
//            if (title == null || career == null || placement == null || video.isEmpty() || document.isEmpty() || createdOn == null) {
//                response.put("msg", "title, career, placement, video, and document are required");
//                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
//            }
//
//            String filepath = Paths.get('').toAbsolutePath().toString();
//            Path videoUrl = Paths.get(filepath,"src","main","resources","static","videos", video.getOriginalFilename());
//            String videoPath = video.getOriginalFilename();
//            video.transferTo(videoUrl);
//
//            Blogs blogs = Blogs.builder()
//                    .video(videoPath)
//                    .build();
//
//            Blogs addedBlog = blogService.addBlogs(newBlog, video, document);
//
//            response.put("msg", "Blog added successfully");
//            response.put("BlogId", addedBlog.getId());
//            return ResponseEntity.status(HttpStatus.CREATED).body(response);
//        } catch (Exception e) {
//            response.put("msg", "An error occurred while adding the blog");
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
//        }
//    }


//    @PostMapping("/add-blogs")   11111 preference running
//    public ResponseEntity<Map<String, Object>> addBlogs(
//            @RequestParam("title") String title,
//            @RequestParam("career") String career,
//            @RequestParam("placement") String placement,
//            @RequestParam("video") MultipartFile video,
//            @RequestParam("document") MultipartFile document) {
//
//        Map<String, Object> response = new HashMap<>();
//        try {
//            // Validate required fields
//            if (title == null || title.isEmpty() || video.isEmpty() || document.isEmpty()) {
//                response.put("msg", "Title, video, and document are required");
//                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
//            }
//
//            // Save video to the desired location
//            Path videoPath = Paths.get("src", "main", "resources", "static", "videos", video.getOriginalFilename());
//            Files.createDirectories(videoPath.getParent());  // Ensure directories exist
//            video.transferTo(videoPath);  // Save the video
//
//            // Save document to the desired location
//            Path documentPath = Paths.get("src", "main", "resources", "static", "documents", document.getOriginalFilename());
//            Files.createDirectories(documentPath.getParent());  // Ensure directories exist
//            document.transferTo(documentPath);  // Save the document
//
//            // Create a new blog instance
//            Blogs blog = Blogs.builder()
//                    .title(title)
//                    .career(career)  // Save career as a string
//                    .placement(placement)  // Save placement as a string
//                    .video(videoPath.toString())  // Convert Path to string
//                    .document(documentPath.toString())  // Convert Path to string
//                    .created_on(java.time.LocalDate.now())
//                    .build();
//
//            // Save the blog using the service
//            Blogs addedBlog = blogService.addBlogs(blog);
//
//            response.put("msg", "Blog added successfully");
//            response.put("BlogId", addedBlog.getId());
//            return ResponseEntity.status(HttpStatus.CREATED).body(response);
//
//        } catch (IOException e) {
//            response.put("msg", "An error occurred while adding the blog");
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
//        }
//    }














//    @PostMapping("/add-blogs")3333333333 running
//    public ResponseEntity<Map<String, Object>> addBlogs(
//            @RequestParam("title") String title,
//            @RequestBody Career career,
//            @RequestBody Placement placement,
//            @RequestParam("video") MultipartFile video,
//            @RequestParam("document") MultipartFile document) {
//
//        Map<String, Object> response = new HashMap<>();
//        try {
//            // Validate required fields
//            if (title == null || title.isEmpty() || video.isEmpty() || document.isEmpty()) {
//                response.put("msg", "Title, video, and document are required");
//                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
//            }
//
//            // Save video to the desired location
//            String videoPath = Paths.get("src", "main", "resources", "static", "videos", video.getOriginalFilename()).toString();
//            video.transferTo(Paths.get(videoPath).toAbsolutePath());
//
//            // Save document to the desired location
//            String documentPath = Paths.get("src", "main", "resources", "static", "documents", document.getOriginalFilename()).toString();
//            document.transferTo(Paths.get(documentPath).toAbsolutePath());
//
//            // Create a new blog instance
//            Blogs blog = Blogs.builder()
//                    .title(title)
//                    .video(videoPath)
//                    .career(career)
//                    .placement(placement)
//                    .build();
//
//            // Save the blog using the service
//            Blogs addedBlog = blogService.addBlogs(blog);
//
//            response.put("msg", "Blog added successfully");
//            response.put("BlogId", addedBlog.getId());
//            return ResponseEntity.status(HttpStatus.CREATED).body(response);
//        } catch (Exception e) {
//            response.put("msg", "An error occurred while adding the blog");
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
//        }
//    }







    @PostMapping("/add-notes")
    public ResponseEntity<?> addNotes(@RequestBody Notes notes){
        HashMap<String,Object> response = new HashMap<>();
        try{
            if(notes.getTitle() == null || notes.getContent() == null || notes.getCategory() == null || notes.getWritten_on() == null){
                response.put("msg","title, content, category and written_on are required");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            Notes addedNotes = notesService.addNotes(notes);
            response.put("msg","Notes added successfully");
            response.put("NotesId",addedNotes.getId());
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        }
        catch (RuntimeException e){
            response.put("msg",e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
        }
        catch (Exception e){
            response.put("msg","An error occured while adding course");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/view-notes")
    public ResponseEntity<?> findAllNotes(){
        try{
            List<Notes> notes = notesService.findAllNotes();
            return new ResponseEntity<>(notes,HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request) {
        try {
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate();
            }
            return new ResponseEntity<>(Map.of("msg","Logout successful"), HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}
