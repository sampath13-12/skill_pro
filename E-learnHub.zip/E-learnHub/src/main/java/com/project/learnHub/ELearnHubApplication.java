package com.project.learnHub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ELearnHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(ELearnHubApplication.class, args);
		System.out.println("E-Learn Hub started");
	}

}
