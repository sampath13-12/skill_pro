package com.project.learnHub.service;

import com.project.learnHub.entity.Courses;
import com.project.learnHub.entity.JobNotification;


public interface IAdminService {

    Courses addCourses(Courses course);

    JobNotification addJobNotification(JobNotification jobNotification);




}
