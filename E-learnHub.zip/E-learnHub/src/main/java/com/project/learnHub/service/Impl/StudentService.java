package com.project.learnHub.service.Impl;

import com.project.learnHub.entity.*;
import com.project.learnHub.repository.StudentRepository;
import com.project.learnHub.service.IStudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class StudentService implements IStudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public Student register(Student student) {
        return studentRepository.save(student);
    }

    @Override
    public Object login(String username, String password) {
        Optional<Student> student = studentRepository.findByName(username);
        if (student.isPresent() && student.get().getPassword().equals(password)) {
            return student;
        }
        return Optional.empty();
    }

    @Override
    public Courses viewCourses() {
        return null;
    }

    @Override
    public JobNotification viewJobNotification() {
        return null;
    }

    @Override
    public Blogs addBlogs(Blogs blogs) {
        return null;
    }

    @Override
    public Blogs viewBlogs() {
        return null;
    }

    @Override
    public Notes addNotes(Notes notes) {
        return null;
    }

    @Override
    public Notes viewNotes() {
        return null;
    }
}
